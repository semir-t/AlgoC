/* Includes **************************************************************** */
#include <Arduino.h>
#include "algomotor.h"
#include "algobot.h"
#include "systim.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* AlgoMotor MotorA(MOTOR_A_DIR, MOTOR_A_PWM); */
/* AlgoMotor MotorB(MOTOR_B_DIR, MOTOR_B_PWM); */
/* AlgoMotor MotorC(MOTOR_C_DIR, MOTOR_C_PWM); */


AlgoMotor MotorA(MOTOR_A_DIR, MOTOR_A_PWM,(uint16_t *) &TCNT3,(uint8_t *) &TIFR3,(uint16_t *)&OCR3A);
AlgoMotor MotorB(MOTOR_B_DIR, MOTOR_B_PWM,(uint16_t *) &TCNT1,(uint8_t *) &TIFR1,(uint16_t *)&OCR1A);
AlgoMotor MotorC(MOTOR_C_DIR, MOTOR_C_PWM,(uint16_t *) &TCNT4,(uint8_t *) &TIFR4,(uint16_t *)&OCR4A);

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoMotor::AlgoMotor(uint8_t dirPin, uint8_t pwmPin,uint16_t * TCNT,uint8_t * TIFR,uint16_t * OCR)
{
    _directionPin = dirPin;
    _pwmPin = pwmPin;
	pinMode(_directionPin,OUTPUT);
	pinMode(_pwmPin,OUTPUT);
    pOCR = OCR;
    pTCNT = TCNT;
    pTIFR = TIFR;
}

void AlgoMotor::run(float time,uint8_t power,uint8_t dir,uint8_t status)
{
    this->direction = dir;
    this->period = time * 1000;
    this->timer = getSYSTIM();
    digitalWrite(_directionPin, dir);
    setPower(power);
    if(status == OP_STATUS_BLOCKING)
    {
        this->state = ALGOMOTOR_STATE_ON;
        delay(this->period);
        if(this->period != FOREVER)
        {
            stop();
        }
    }
    else
    {
        if(this->period == FOREVER)
        {
            this->state = ALGOMOTOR_STATE_ON;
        }
        else
        {
            this->state = ALGOMOTOR_STATE_TIMED_ON;
        }
    }
}

void AlgoMotor::changeSpeed(uint8_t pwm) 
{
    pwmValue = pwm;
    switch(_pwmPin) 
    {
        case (MOTOR_A_PWM): 
        {
            switch (pwmValue) 
            {
                case 0:
                case 255: 
                {
                    outputState = 0; 
                    TIMSK2 = (TIMSK2 & B11111101) | B00000000; // Disable Compare A Interrupt
                    digitalWrite(_pwmPin, pwmValue);
                    break;
                }
                default: 
                {
                    OCR2A = pwmValue;
                    TIMSK2 = (TIMSK2 & B11111101) | B00000010; // Enable Compare A Interrupt
                    break;
                }
            }
            break;
        }
        case (MOTOR_B_PWM): 
        {
            switch(pwmValue) 
            {
                case 0:
                case 255: 
                {
                    outputState = 0; 
                    TIMSK2 = (TIMSK2 & B11111011) | B00000000; // Disable Compare B Interrupt
                    digitalWrite(_pwmPin, pwmValue);
                    break;
                }
                default: 
                {
                    OCR2B = pwmValue;
                    TIMSK2 = (TIMSK2 & B11111011) | B00000100; // Enable Compare B Interrupt
                    break;
                }
            }
            break;
        }
        default: 
        {
            analogWrite(_pwmPin, pwmValue);
            break;
        }
    }
}

void AlgoMotor::stop(void) 
{
    state = ALGOMOTOR_STATE_OFF;
    changeSpeed(0);
}
uint32_t AlgoMotor::getRuntime(void)
{
    return getElapsedTimeSYSTIM(timer);		
}

void AlgoMotor::setPower(uint32_t power)
{
    uint32_t value = (power * 255)/MOTOR_POWER_LEVEL_CNT;
    changeSpeed(value);
}

void AlgoMotor::setRotationCnt(float rot)
{
    uint16_t pulseCnt = rot * 2 * 360;
    Serial.print("Pulse cnt: ");
    Serial.println(pulseCnt);
    *pOCR = pulseCnt;
    *pTCNT = 0;
    *pTIFR = 0;
}

uint8_t Move(AlgoMotor & motor,float time,uint8_t power,uint8_t dir)
{
    motor.run(time,power,dir,OP_STATUS_BLOCKING);
}

uint8_t Move(AlgoMotor & motor,float time,uint8_t power,uint8_t dir,uint8_t mode)
{
    motor.run(time,power,dir,mode);
}

uint8_t MoveAB(float time,uint8_t power,uint8_t dir)
{
    Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
    Move(MotorB,time,power,dir,OP_STATUS_BLOCKING);
}
uint8_t MoveAB(float time,uint8_t power,uint8_t dir, uint8_t mode)
{
    if(mode == OP_STATUS_BLOCKING)
    {
        Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
        Move(MotorB,time,power,dir,OP_STATUS_BLOCKING);
    }
    else
    {
        Move(MotorA,time,power,dir,mode);
        Move(MotorB,time,power,dir,mode);
    }
}
uint8_t MoveABC(float time,uint8_t power,uint8_t dir)
{
    Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
    Move(MotorB,time,power,dir,OP_STATUS_NONBLOCKING);
    Move(MotorC,time,power,dir,OP_STATUS_BLOCKING);
}
uint8_t MoveABC(float time,uint8_t power,uint8_t dir,uint8_t mode)
{
    if(mode == OP_STATUS_BLOCKING)
    {
        Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
        Move(MotorB,time,power,dir,OP_STATUS_NONBLOCKING);
        Move(MotorC,time,power,dir,OP_STATUS_BLOCKING);
    }
    else
    {
        Move(MotorA,time,power,dir,mode);
        Move(MotorB,time,power,dir,mode);
        Move(MotorC,time,power,dir,mode);
    }

}


uint8_t Rotations(AlgoMotor & motor,float rot,uint8_t power,uint8_t dir)
{
    Rotations(motor,rot,power,dir,OP_STATUS_BLOCKING);
}
uint8_t Rotations(AlgoMotor & motor,float rot,uint8_t power,uint8_t dir,uint8_t mode)
{
    motor.setRotationCnt(rot);
    motor.run(FOREVER,power,dir,mode);
    if(mode == OP_STATUS_BLOCKING)
    {
        Serial.println("Blocking mode");
        while(motor.state == ALGOMOTOR_STATE_ON)
        {
            delay(100);
            Serial.print("Motor state: ");
            Serial.println(motor.state);
        }
        Serial.println("Done");
    }
}


uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,BLOCKING); 
}
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir,uint8_t mode)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,mode); 
}
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,NONBLOCKING); 
    Rotations(C,rot,power,dir,BLOCKING); 

}
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir,uint8_t mode)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,NONBLOCKING); 
    Rotations(C,rot,power,dir,mode); 
}

void StopMotor(AlgoMotor & motor)
{
    motor.stop();
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
