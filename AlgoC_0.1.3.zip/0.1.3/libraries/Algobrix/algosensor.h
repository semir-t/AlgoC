/*
  * Documentation on the Distance AlgoSensor:
  * Senses distance between 2 - 100 centimeters
  * The 100 cm is divided between 0-10 in the code
  * 0-2 cm will match sensor output of 0 --> Sense below 2 cm --> False
  * 2-20 .......................... of 1-2 --> Low / True
  * 20-50 ......................... of 3-5 --> Med / True
  * 50-100 ........................ of 5-10 --> High / True
  * 100+ ...........................of 0 --> Sense above 100 cm --> False
*/
/* Define to prevent recursive inclusion *********************************** */
#ifndef __SENSOR_H
#define __SENSOR_H

/* Includes **************************************************************** */
#include <Arduino.h>

/* Exported constants ****************************************************** */
#define NUM_OF_SENSORS 2
/* #define PULSE_TIMEOUT 4000ul // ul = unsigned long */
#define PULSE_TIMEOUT 10000ul // ul = unsigned long
#define CYCLE_TIME 2000.0f // 2 MS @ Microseconds 500Hz Frequency // f = float
                           //
/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoSensor 
{
    private:
        uint8_t pin;

    public:
        AlgoSensor(uint8_t pin);
        uint8_t getValue();
};

/* Exported variables ****************************************************** */
extern AlgoSensor Sensor1;
extern AlgoSensor Sensor2;


/* Exported functions ****************************************************** */
uint8_t Sensor(AlgoSensor & sensor);
uint8_t Sensor(uint8_t port);

uint8_t waitSensor(uint8_t port, int8_t value);
uint8_t waitSensor(uint8_t port, uint8_t min_value, uint8_t max_value);

#endif 
/* ***************************** END OF FILE ******************************* */

