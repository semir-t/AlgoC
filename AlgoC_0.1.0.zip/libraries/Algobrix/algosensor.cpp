/* Includes **************************************************************** */
#include <algosensor.h>

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
AlgoSensor Sensor1(SENSOR_A_PIN);
AlgoSensor Sensor2(SENSOR_B_PIN);

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoSensor::AlgoSensor(uint8_t pin) 
{
    this->pin = pin;
    pinMode(pin, INPUT);
}


uint8_t AlgoSensor::getValue() 
{
    float dutyCycle = 0;
    unsigned long pwmHighValue = pulseIn(pin, HIGH, PULSE_TIMEOUT);
    if(pwmHighValue != 0) 
    {
        dutyCycle = (float(pwmHighValue) / CYCLE_TIME) * 100.0f;
    } 
    else if (digitalRead(pin)) 
    {
        dutyCycle = 100;
    } 
    else 
    {
        dutyCycle = 0;
    }
    uint8_t temp = uint8_t(round(dutyCycle / 10));
    return uint8_t(round(dutyCycle / 10));
}


uint8_t Sensor(AlgoSensor & sensor)
{
    return sensor.getValue();
}
uint8_t Sensor(uint8_t port)
{
    switch(port)
    {
        case(1):
        {
            return Sensor1.getValue();
            break;
        }
        case(2):
        {
            return Sensor2.getValue();
            break;
        }
        default:
        {

        }

    }
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
