/* Includes **************************************************************** */
#include "algobot.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* Private function prototypes ********************************************* */
static void initMOTOR(void);
static void initUI(void);
static void initLIGHT(void);
static void chkMOTOR(void);
static void chkLIGHT(void);
/* static void chkMOTOR(void); */

/* Exported functions ****************************************************** */
void initALGOBOT(void)
{
    initMOTOR();
    initLIGHT();
    initUI();

    uint32_t timer = getSYSTIM();
    uint8_t state = 0;
    while(1)
    {
        if(chk4TimeoutSYSTIM(timer,200) == SYSTIM_TIMEOUT)
        {
            timer = getSYSTIM();
            state ^= 0x01;
            digitalWrite(PLAY_LED_PIN,state);
        }
        if(digitalRead(PLAY_BUTTON_PIN) == 0)
        {
            digitalWrite(PLAY_LED_PIN,0);
            break;
        }
    }
}

void chkALGOBOT(void)
{
    chkMOTOR();
    chkLIGHT();
    
}

void yield(void)
{
    chkALGOBOT();
}

/* Private functions ******************************************************* */
void initMOTOR(void)
{
  // Initialize TIMER2 for PWM of motors A and B.
  TCNT2 = 0;
  TIFR2 = 0;
  TCCR2A = 0;
  TCCR2B = (TCCR2B & B11111100) | B00000011;  // Clock I/O with prescaler of 64.
  OCR2A = 0;                                  // Compare Value A - for motor A
  OCR2B = 0;                                  // Compare Value B - for motor B
  TIMSK2 = (TIMSK2 & B11111111) | B00000000;  // Timer2 disabled by default - enabled when used for enabling the motors.
}

void chkMOTOR(void)
{
    if(MotorA.state == ALGOMOTOR_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(MotorA.timer,MotorA.period) == SYSTIM_TIMEOUT)
        {
            MotorA.stop();
        }
    }
    if(MotorB.state == ALGOMOTOR_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(MotorB.timer,MotorB.period) == SYSTIM_TIMEOUT)
        {
            MotorB.stop();
        }
    }
    if(MotorC.state == ALGOMOTOR_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(MotorC.timer,MotorC.period) == SYSTIM_TIMEOUT)
        {
            MotorC.stop();
        }
    }
}

void initLIGHT(void)
{
    Light1.stop();
    Light2.stop();
}
void chkLIGHT(void)
{
    if(Light1.state == ALGOLED_LIGHT_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(Light1.timer,Light1.period) == SYSTIM_TIMEOUT)
        {
            Light1.stop();
        }
    }
    if(Light2.state == ALGOLED_LIGHT_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(Light2.timer,Light2.period) == SYSTIM_TIMEOUT)
        {
            Light2.stop();
        }
    }
}

void initUI(void)
{
	pinMode(PLAY_LED_PIN,OUTPUT);
    pinMode(PLAY_BUTTON_PIN,INPUT);
	/* pinMode(POWER_LED_PIN,OUTPUT); */
}

ISR(TIMER2_COMPA_vect) 
{
  noInterrupts();
  if(MotorA.outputState) 
  {
    digitalWrite(MOTOR_A_PWM, LOW);
    OCR2A = 0;
    MotorA.outputState = 0;
  } 
  else 
  {
    digitalWrite(MOTOR_A_PWM, HIGH);
    OCR2A = MotorA.pwmValue;
    MotorA.outputState = 1;
  }
  interrupts();
}

ISR(TIMER2_COMPB_vect) 
{
  noInterrupts();
  if(MotorB.outputState) 
  {
    digitalWrite(MOTOR_B_PWM, LOW);
    OCR2B = 0;
    MotorB.outputState = 0;
  } 
  else 
  {
    digitalWrite(MOTOR_B_PWM, HIGH);
    OCR2B = MotorB.pwmValue;
    MotorB.outputState = 1;
  }
  interrupts();
}



/* ***************************** END OF FILE ******************************* */
