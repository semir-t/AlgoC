/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOLIGHT_H
#define __ALGOLIGHT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <neopixel.h>

/* Exported constants ****************************************************** */
#define LIGHT_POWER_LEVEL_CNT                           10

enum ALGOLED_LIGHT_STATE
{
	ALGOLED_LIGHT_STATE_OFF = 0x00,
	ALGOLED_LIGHT_STATE_ON,
    ALGOLED_LIGHT_STATE_TIMED_ON,
};

enum ALGOLED_LIGHT_COLOR
{
    LIGHT_COLOR_WHITE = 0xffffff,
    LIGHT_COLOR_RED = 0xff0000,
    LIGHT_COLOR_GREEN = 0x00ff00,
    LIGHT_COLOR_BLUE = 0x0000ff,
    LIGHT_COLOR_PURPLE = 0xff00ff,
    LIGHT_COLOR_YELLOW = 0x00ffff,
};
/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoLight
{
    private:
        NeoPixel neoPixelLed;
        uint8_t _pin;
    public:
        uint8_t state;
        uint32_t period;
        uint32_t timer;
		AlgoLight(uint8_t pin);
        void setColor(uint8_t r,uint8_t g,uint8_t b);
        void stop(void);
};

/* Exported variables ****************************************************** */
extern AlgoLight Light1;
extern AlgoLight Light2;


/* Exported functions ****************************************************** */
void Light(AlgoLight & light, float time,uint8_t power,uint32_t color);
void Light(AlgoLight & light, float time,uint8_t power,uint32_t color, uint8_t status);
void Light(uint8_t port,float time,uint8_t power,uint32_t color);
void Light(uint8_t port,float time,uint8_t power,uint32_t color,uint8_t status);
void Light12(float time,uint8_t power,uint32_t color);
void Light12(float time,uint8_t power,uint32_t color,uint8_t status);
void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B);
void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status);
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B);
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status);

#endif 
/* ***************************** END OF FILE ******************************* */


